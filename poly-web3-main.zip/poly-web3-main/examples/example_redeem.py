# -*- coding = utf-8 -*-
# @Time: 2025-12-27 17:01:20
# @Author: PinBar
# @Site:
# @File: example_redeem.py
# @Software: PyCharm
import os

import dotenv
from py_builder_relayer_client.client import RelayClient
from py_builder_signing_sdk.config import BuilderConfig
from py_builder_signing_sdk.sdk_types import BuilderApiKeyCreds

from py_clob_client.client import ClobClient

from poly_web3 import RELAYER_URL, PolyWeb3Service
import time

dotenv.load_dotenv()

